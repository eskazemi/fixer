from setuptools import setup

setup(
    version="0.0.2",
    name="fixer-demo",
    author="Esmaeil Kazemi",
    author_email="m.esmaeilkazemi@gmail.com",
    packages=["fixer"],
    license="MIT",
    install_requires=['requests'],
    url="#",
    zip_safe=False,
)

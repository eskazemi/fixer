from setuptools import setup

setup(
    version="0.0.1",
    name="fixer-demo",
    author="Esmaeil Kazemi",
    author_email="m.esmaeilkazemi@gmail.com",
    packages=["fixer"],
    url="#",
    zip_safe=False,
)
